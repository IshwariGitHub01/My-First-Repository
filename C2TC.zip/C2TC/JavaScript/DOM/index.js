document;
#document<!doctype ><html lang=​"en">​<head>​…​</head>​<body>​…​</body>​</html>​

document.firstElementChild;
<html lang=​"en">​<head>​…​</head>​<body>​…​</body>​</html>​

document.lastElementChild;
<html lang=​"en">​<head>​…​</head>​<body>​…​</body>​</html>​

document.firstElementChild.firstElementChild;
<head>​…​</head>​

document.firstElementChild.lastElementChild;
<body>​…​</body>​

document.firstElementChild.lastElementChild.firstElementChild;
<h1 id=​"title">​HELLO​</h1>​

document.firstElementChild.lastElementChild.lastElementChild;
<script src=​"index.js" charset=​"utf-8">​</script>​

document.firstElementChild.lastElementChild.children[3];
<input type=​"checkbox">​

document.getElementById("title");
<h1 id=​"title">​HELLO​</h1>​

document.getElementById("btn");
null

document.getElementById("list");
<ul id=​"list">​…​</ul>​

document.querySelector("btn");
null

document.querySelector(".btn");
<button class=​"btn">​ClickMe​</button>

//JavaScript uses querrySelector widely
undefined
document.querySelector("h1");
<h1 id=​"title">​HELLO​</h1>​
document.querySelector("h1").style.color="blue";    //to change color
"blue"


document.querySelectorAll("#list.item")[1].style.color="red";

document.querySelectorAll("button").style.backgroundColor="green";

document.querySelector("h1").innerHTML="Good Morning";
"Good Morning"

document.querySelector("h1").style.color="blue";
"blue"

document.querySelector("h1").innerHTML="Good Morning <em>ALL</em>";
"Good Morning <em>ALL</em>"


document.querySelector(".item1");
<li class=​"item1">​…​</li>​
document.querySelector(".item2");
<li class=​"item2">​Second​</li>​
document.querySelector(".item3");
<li class=​"item3">​Third​</li>​
let item3=document.querySelector(".item3");
undefined
item3.remove();
undefined


let item=document.querySelector(".item1");
undefined
item.textContent="Java";
"Java"

let im=document.querySelector(".item2");
undefined
im.textContent="Full Stack";
"Full Stack"

​