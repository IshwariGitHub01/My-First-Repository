//for player1

//random starts with first location
var randomNum1=Math.floor(Math.random()*6)+1;

//mapping random images to my folder
var randomImage1="images/dice"+randomNum1+".png";

var image1=document.querySelectorAll("img")[0];
image1.setAttribute("src",randomImage1);


//for player2

//random starts with first location
var randomNum2=Math.floor(Math.random()*6)+1;

//mapping random images to my folder
var randomImage2="images/dice"+randomNum2+".png";

var image2=document.querySelectorAll("img")[1];
image2.setAttribute("src",randomImage2);


//for player3

//random starts with first location
var randomNum3=Math.floor(Math.random()*6)+1;

//mapping random images to my folder
var randomImage3="images/dice"+randomNum3+".png";

var image3=document.querySelectorAll("img")[2];
image3.setAttribute("src",randomImage3);


//for player4

//random starts with first location
var randomNum4=Math.floor(Math.random()*6)+1;

//mapping random images to my folder
var randomImage4="images/dice"+randomNum4+".png";

var image1=document.querySelectorAll("img")[3];
image4.setAttribute("src",randomImage4);


//logic to decide winner

if(randomNum1>randomNum2)
{
	if(randomNum1>randomNum3)
	{
		if(randomNum1>randomNum4)
		{
			document.querySelector("h1").innerHTML="Player 1 wins";
		}
	}
}
else if(randomNum2>randomNum1)
{
	if(randomNum2>randomNum3)
	{
		if(randomNum2>randomNum4)
		{
			document.querySelector("h1").innerHTML="Player 2 wins";
		}
	}
}

else if(randomNum3>randomNum1)
{
	if(randomNum3>randomNum2)
	{
		if(randomNum3>randomNum4)
		{
			document.querySelector("h1").innerHTML="Player 3 wins";
		}
	}
}

else if(randomNum4>randomNum1)
{
	if(randomNum4>randomNum2)
	{
		if(randomNum4>randomNum3)
		{
			document.querySelector("h1").innerHTML="Player 4 wins";
		}
	}
}
else
{
	document.querySelector("h1").innerHTML="Draw";
}
